
let groupMessage={
    sender:"",
    message:"",
}

export {groupMessage}