import { initializeApp } from "firebase/app";
import { getFirestore,collection, addDoc } from "firebase/firestore";
const firebaseConfig = {
    apiKey: "AIzaSyDk53KyMpPmX6blCDISkg-yF4-qEXA82hw",
    authDomain: "tweeter-89ead.firebaseapp.com",
    projectId: "tweeter-89ead",
    storageBucket: "tweeter-89ead.appspot.com",
    messagingSenderId: "1007916827539",
    appId: "1:1007916827539:web:c9be969d190aa26c355e66",
    measurementId: "G-M33JKGLTK0"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);

//  Creatng public messages
function displayPublicMessages(){
// TODO grab the list of messages and create a html struct that can handle them all
}

document.getElementById('send').addEventListener('click', () => {
    const usrMsg = document.getElementById('usrMsg');
    const docUser =document.getElementById('curUser');
    const curUser =docUser.value.trim();
    const curMessage = usrMsg.value.trim();
    if (curMessage) {
        // TODO Add in firebase send api
        const docRef = addDoc(collection(db,'pubmessage'),{
            message:`${curMessage}`,
            userName:`${curUser}`
        });
        usrMsg.value = '';
        docUser.value='';
    }
});